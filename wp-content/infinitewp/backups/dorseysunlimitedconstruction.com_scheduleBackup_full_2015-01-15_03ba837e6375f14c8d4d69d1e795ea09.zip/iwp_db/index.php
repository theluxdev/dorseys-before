<?php
			global $old_url, $old_file_path;
			$old_url = 'http://www.dorseysunlimitedconstruction.com';
			$old_file_path = '/home/dorseyun/public_html/';
			